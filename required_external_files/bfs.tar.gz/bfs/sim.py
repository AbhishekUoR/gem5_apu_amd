#! /usr/bin/env python

import os
import inspect

exe = 'bfs'

this_file = inspect.currentframe().f_code.co_filename
sim_root = os.path.dirname(os.path.abspath(this_file))

size_map = ['16', '512', '4096', '65536', '1MW_6']

def size2opts(size):
    try:
        return os.path.join(RODINIA_DATA, 'bfs/graph%s.bin' % size_map[size])
    except IndexError:
        print 'Size argument out of range'
        import sys
        sys.exit(1)

basefile = os.path.join(sim_root, '..', '..', 'sim-base.py')
execfile(basefile)
